# ⚽ 노스웨스트 사람들 (NOWESA) 공식 웹사이트

영국 프리미어리그 북서부 축구 유튜브 채널 **‘노스웨스트 사람들 (NOWESA)’**의 공식 랜딩페이지 및 팬 커뮤니티입니다.

- **유튜브 채널**: https://youtube.com/channel/UCq9_Daq3YznD-JQUfETIa0w?si=Iff0gPz6uiPUm-cU
- **인스타그램**: https://instagram.com/nowesa.official
- **공식 문의**: nowesa.official@gmail.com

## Vercel 배포 방법 (초간단 1분 컷)
1. 깃허브(GitHub)에 새 레포지토리 생성 후 이 폴더의 파일들을 업로드합니다.
2. Vercel(vercel.com)에 로그인 후 해당 레포지토리를 Import합니다.
3. [Deploy] 버튼만 누르면 즉시 전 세계 접속 가능한 웹사이트 주소가 발급됩니다!
